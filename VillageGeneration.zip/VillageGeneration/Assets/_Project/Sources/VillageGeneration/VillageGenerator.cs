﻿using System;
using System.Collections.Generic;
using System.Linq;
using Sources.PathFinding;
using Sources.ScriptableObjects;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Sources.VillageGeneration
{
    public class VillageGenerator : MonoBehaviour
    {
        private struct PlacedBuilding
        {
            public BuildingData Data { get; }
            public Vector2Int Origin { get; }
            public Vector2Int Entrance { get; }

            public PlacedBuilding(BuildingData data, Vector2Int origin, Vector2Int entrance)
            {
                Data = data;
                Origin = origin;
                Entrance = entrance;
            }
        }

        [Header("References")] 
        [SerializeField] private Tilemap _roadTilemap;
        [SerializeField] private RuleTile _roadTile;
        [Header("Building Assets")] 
        [SerializeField] private BuildingData _elderHouse;

        [SerializeField] private List<BuildingData> _specialBuildingsPool;
        [SerializeField] private BuildingData _housePrefab;
        [SerializeField] private BuildingData _farmPrefab;

        [Header("Settings")] [SerializeField] private int _farmThreshold = 3;
        [SerializeField] private int _specialBuildingsThreshold = 5;
        [SerializeField] private float _areaMultiplier = 1.5f;
        [SerializeField] private int _mapMargin = 5;
        [SerializeField] private int _minSpacing = 2;
        [SerializeField] private int _maxSpacing = 5;

        private Pathfinder _pathfinder;
        private int _targetBuildingCount;
        private int _roadWidth;
        private float _tileSize;
        private int _mapWidth;
        private int _mapHeight;
        private CellType[,] _grid;
        private List<Vector2Int> _roadNetwork;
        private List<PlacedBuilding> _placedBuildings;

        public event Action<VillageGenerationResult> OnVillageGenerated;

        public void Init(Pathfinder pathfinder)
        {
            _pathfinder = pathfinder;
            _roadNetwork = new List<Vector2Int>();
            _placedBuildings = new List<PlacedBuilding>();
        }

        public void Generate(int buildingCount, int roadWidth, float tileSize)
        {
            _targetBuildingCount = buildingCount;
            _roadWidth = roadWidth;
            _tileSize = tileSize;

            List<BuildingData> buildingQueue = CreateBuildingPlan(_targetBuildingCount);
            CalculateMapSize(buildingQueue);
            InitializeGrid();

            PlaceBuilding(_elderHouse, forceCenter: true);

            if (_placedBuildings.Count > 0)
            {
                Vector2Int startPoint = _placedBuildings[0].Entrance;
                ApplyRoadBrush(startPoint);
                ApplyRoadBrush(startPoint + Vector2Int.down);
            }

            foreach (BuildingData b in buildingQueue.OrderByDescending(b => b.Width * b.Height))
                PlaceBuilding(b);

            ConnectBuildings();

            OnVillageGenerated?.Invoke(new VillageGenerationResult(_mapWidth, _mapHeight, _tileSize, _grid));
        }

        private void Cleanup()
        {
            _roadTilemap.ClearAllTiles();

            for (int i = transform.childCount - 1; i >= 0; i--)
                Destroy(transform.GetChild(i).gameObject);

            _roadNetwork.Clear();
            _placedBuildings.Clear();
        }

        private void InitializeGrid() =>
            _grid = new CellType[_mapWidth, _mapHeight];

        private List<BuildingData> CreateBuildingPlan(int totalCount)
        {
            List<BuildingData> plan = new();

            int farmCount = totalCount / _farmThreshold;
            int specialCount = totalCount / _specialBuildingsThreshold;

            int resCount = Mathf.Max(0, totalCount - farmCount - specialCount);

            for (int i = 0; i < farmCount; i++)
                plan.Add(_farmPrefab);

            if (specialCount > 0)
                plan.AddRange(_specialBuildingsPool.OrderBy(x =>
                    UnityEngine.Random.value).Take(specialCount));

            for (int i = 0; i < resCount; i++) plan.Add(_housePrefab);

            return plan;
        }

        private void CalculateMapSize(List<BuildingData> plan)
        {
            float totalArea = GetBuildingAreaWithPadding(_elderHouse);

            foreach (var b in plan)
                totalArea += GetBuildingAreaWithPadding(b);

            totalArea *= _areaMultiplier;
            int side = Mathf.CeilToInt(Mathf.Sqrt(totalArea));

            _mapWidth = side + _mapMargin * 2;
            _mapHeight = side + _mapMargin * 2;
        }

        private int GetBuildingAreaWithPadding(BuildingData data) =>
            (data.Width + _maxSpacing) * (data.Height + _maxSpacing);

        private void PlaceBuilding(BuildingData building, bool forceCenter = false)
        {
            int maxAttempts = 100;
            for (int i = 0; i < maxAttempts; i++)
            {
                int spacing = UnityEngine.Random.Range(_minSpacing, _maxSpacing + 1);
                int x, y;

                if (forceCenter)
                {
                    x = (_mapWidth / 2) - (building.Width / 2);
                    y = (_mapHeight / 2) - (building.Height / 2);
                }
                else
                {
                    x = UnityEngine.Random.Range(spacing, _mapWidth - building.Width - spacing);
                    y = UnityEngine.Random.Range(spacing, _mapHeight - building.Height - spacing);
                }

                if (CanPlace(x, y, building.Width, building.Height, spacing))
                {
                    SpawnPrefab(building, x, y);
                    MarkGrid(x, y, building.Width, building.Height, CellType.Building);
                    Vector2Int entrance = new Vector2Int(x + (building.Width / 2), y - 1);
                    _placedBuildings.Add(new PlacedBuilding(building, new Vector2Int(x, y), entrance));
                    return;
                }
            }
        }

        private bool CanPlace(int startX, int startY, int width, int height, int spacing)
        {
            for (int x = startX - spacing; x < startX + width + spacing; x++)
            {
                for (int y = startY - spacing; y < startY + height + spacing; y++)
                {
                    if (x < 0 || y < 0 || x >= _mapWidth || y >= _mapHeight)
                        return false;

                    if (_grid[x, y] != CellType.Empty)
                        return false;
                }
            }

            return true;
        }

        private void MarkGrid(int startX, int startY, int width, int height, CellType type)
        {
            for (int x = startX; x < startX + width; x++)
            for (int y = startY; y < startY + height; y++)
                _grid[x, y] = type;
        }

        private void SpawnPrefab(BuildingData building, int x, int y)
        {
            GameObject obj = Instantiate(building.Prefab, new Vector3(x * _tileSize, y * _tileSize, 0),
                Quaternion.identity);
            obj.name = building.BuildingName;
            obj.transform.SetParent(transform);
        }

        private void ConnectBuildings()
        {
            Vector2Int center = new Vector2Int(_mapWidth / 2, _mapHeight / 2);
            var sortedBuildings = _placedBuildings.OrderBy(b => Vector2Int.Distance(b.Origin, center)).ToList();

            foreach (var building in sortedBuildings)
            {
                if (_roadNetwork.Contains(building.Entrance)) continue;

                Vector2Int targetRoad = FindNearestRoadTile(building.Entrance);

                List<Vector2Int> path =
                    _pathfinder.FindPath(building.Entrance, targetRoad, _grid, _mapWidth, _mapHeight);

                if (path != null)
                    foreach (Vector2Int step in path)
                        ApplyRoadBrush(step);
            }
        }

        private Vector2Int FindNearestRoadTile(Vector2Int start)
        {
            Vector2Int best = start;
            float minDst = float.MaxValue;

            foreach (Vector2Int p in _roadNetwork)
            {
                float dst = Vector2Int.Distance(start, p);
                if (dst < minDst)
                {
                    minDst = dst;
                    best = p;
                }
            }

            return best;
        }

        private void ApplyRoadBrush(Vector2Int center)
        {
            int offset = _roadWidth / 2;
            for (int x = -offset; x < _roadWidth - offset; x++)
            for (int y = -offset; y < _roadWidth - offset; y++)
                AddRoadTile(new Vector2Int(center.x + x, center.y + y));
        }

        private void AddRoadTile(Vector2Int pos)
        {
            if (pos.x < 0 || pos.y < 0 || pos.x >= _mapWidth || pos.y >= _mapHeight)
                return;

            if (_grid[pos.x, pos.y] == CellType.Building)
                return;

            _grid[pos.x, pos.y] = CellType.Road;
            _roadTilemap.SetTile(new Vector3Int(pos.x, pos.y, 0), _roadTile);

            if (!_roadNetwork.Contains(pos))
                _roadNetwork.Add(pos);
        }
        
        private void OnDrawGizmos()
        {
            if (_grid == null)
                return;
            
            Gizmos.color = Color.yellow;
            Vector3 mapCenter = new Vector3(_mapWidth * _tileSize / 2f, _mapHeight * _tileSize / 2f, 0);
            Vector3 mapSize = new Vector3(_mapWidth * _tileSize, _mapHeight * _tileSize, 1f);
            Gizmos.DrawWireCube(mapCenter, mapSize);

            for (int x = 0; x < _mapWidth; x++)
            {
                for (int y = 0; y < _mapHeight; y++)
                {
                    CellType type = _grid[x, y];

                    if (type == CellType.Empty)
                        continue;

                    Gizmos.color = type switch
                    {
                        CellType.Building => new Color(1f, 0f, 0f, 0.4f), // Красный
                        CellType.Road => new Color(0.2f, 0.2f, 0.2f, 0.5f), // Темно-серый
                        CellType.Obstacle => new Color(0f, 0f, 1f, 0.4f), // Синий
                        _ => Color.clear
                    };
                    
                    float offset = _tileSize * 0.5f;
                    Vector3 center = new Vector3((x * _tileSize) + offset, (y * _tileSize) + offset, 0);
                    
                    Vector3 size = new Vector3(_tileSize * 0.9f, _tileSize * 0.9f, 0.1f);

                    Gizmos.DrawCube(center, size);
                }
            }
        }
    }
}