﻿namespace Sources.VillageGeneration
{
    public enum BuildingType
    {
        Unique,
        Residential,
        Farm
    }
}