﻿namespace Sources.VillageGeneration
{
    public class VillageGenerationResult
    {
        public int Width { get; }
        public int Height { get; }
        public float TileSize { get; }
        public CellType[,] Grid { get; }

        public VillageGenerationResult(int width, int height, float tileSize, CellType[,] grid)
        {
            Width = width;
            Height = height;
            TileSize = tileSize;
            Grid = grid;
        }
    }
}