﻿namespace Sources.VillageGeneration
{
    public enum CellType
    {
        Empty,
        Building,
        Road,
        Obstacle
    }
}