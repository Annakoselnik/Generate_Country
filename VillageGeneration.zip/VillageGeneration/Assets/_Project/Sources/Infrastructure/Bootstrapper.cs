﻿using Sources.Camera;
using Sources.Environment;
using Sources.PathFinding;
using Sources.VillageGeneration;
using UnityEngine;

namespace Sources.Infrastructure
{
    public class Bootstrapper : MonoBehaviour
    {
        [Header("Components")]
        [SerializeField] private VillageGenerator _generator;
        [SerializeField] private EnvironmentGenerator _environmentGenerator;
        [SerializeField] private VillageCameraView _cameraView;

        [Header("Input Data")]
        [SerializeField] private int _totalBuildings = 15;
        [Tooltip("Ширина дороги в тайлах")]
        [SerializeField] private int _roadWidth = 2;
        [Tooltip("Размер тайла (PPU)")]
        [SerializeField] private float _tileSize = 1f;

        private Pathfinder _pathfinder;

        private void Start()
        {
            InitializeDependencies();
            SubscribeEvents();
        
            RunGeneration();
        }

        private void OnDestroy() => 
            UnsubscribeEvents();

        private void InitializeDependencies()
        {
            _pathfinder = new Pathfinder();
        
            _cameraView.Init();
            _generator.Init(_pathfinder);
        }

        private void SubscribeEvents()
        {
            _generator.OnVillageGenerated += _environmentGenerator.GenerateEnvironment;
            _generator.OnVillageGenerated += _cameraView.UpdateView;
        }

        private void UnsubscribeEvents()
        {
            if (_generator)
            {
                _generator.OnVillageGenerated -= _environmentGenerator.GenerateEnvironment;
                _generator.OnVillageGenerated -= _cameraView.UpdateView;
            }
        }

        private void RunGeneration()
        {
            _generator.Generate(_totalBuildings, _roadWidth, _tileSize);
        }
    
        [ContextMenu("Restart Generation")]
        public void RestartGeneration()
        {
            RunGeneration();
        }
    }
}