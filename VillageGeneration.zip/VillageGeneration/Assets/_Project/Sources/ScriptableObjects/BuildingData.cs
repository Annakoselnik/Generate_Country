using Sources.VillageGeneration;
using UnityEngine;

namespace Sources.ScriptableObjects
{
    [CreateAssetMenu(fileName = "New Building", menuName = "Village/Building Data")]
    public class BuildingData : ScriptableObject
    {
        [Header("General Info")]
        [SerializeField] private string _buildingName;
        [SerializeField] private BuildingType _type;
        [SerializeField] private GameObject _prefab;

        [Header("Grid Settings")]
        [Tooltip("Ширина здания в тайлах")]
        [SerializeField] private int _width = 4;
        [Tooltip("Высота здания в тайлах")]
        [SerializeField] private int _height = 4;
        [Tooltip("Нужен ли отступ вокруг здания?")]
        [SerializeField] private bool _requiresPadding = true;
    
        public string BuildingName => _buildingName;
        public BuildingType Type => _type;
        public GameObject Prefab => _prefab;
        public int Width => _width;
        public int Height => _height;
        public bool RequiresPadding => _requiresPadding;
    
        [ContextMenu("Calculate Size From Sprite")]
        private void CalculateSize()
        {
            if (_prefab == null)
            {
                Debug.LogWarning($"[{name}] Префаб не назначен. Невозможно вычислить размер.");
                return;
            }

            SpriteRenderer spriteRenderer = _prefab.GetComponentInChildren<SpriteRenderer>();

            if (spriteRenderer == null)
            {
                Debug.LogWarning($"[{name}] В префабе '{_prefab.name}' не найден SpriteRenderer в дочерних объектах.");
                return;
            }
            
            Vector3 size = spriteRenderer.bounds.size;

            _width = Mathf.CeilToInt(size.x);
            _height = Mathf.CeilToInt(size.y);
        
            Debug.Log($"[{name}] Размер установлен: {_width}x{_height} (на основе спрайта {spriteRenderer.gameObject.name})");
        }
    }
}