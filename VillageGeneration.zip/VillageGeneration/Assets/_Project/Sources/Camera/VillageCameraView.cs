﻿using Sources.VillageGeneration;
using UnityEngine;

namespace Sources.Camera
{
    public class VillageCameraView : MonoBehaviour
    {
        [Header("Settings")]
        [SerializeField] private UnityEngine.Camera _camera;
        [SerializeField] private float _padding = 5f;

        public void Init()
        {
            if (_camera == null) 
                _camera = UnityEngine.Camera.main;
        }

        public void UpdateView(VillageGenerationResult data)
        {
            float mapWorldWidth = data.Width * data.TileSize;
            float mapWorldHeight = data.Height * data.TileSize;

            Vector3 centerPosition = new Vector3(mapWorldWidth / 2f, mapWorldHeight / 2f, -10f);
            _camera.transform.position = centerPosition;

            float targetHeight = mapWorldHeight / 2f;
            float targetWidth = (mapWorldWidth / 2f) / _camera.aspect;
            float requiredSize = Mathf.Max(targetHeight, targetWidth);

            _camera.orthographicSize = requiredSize + _padding;
        }
    }
}