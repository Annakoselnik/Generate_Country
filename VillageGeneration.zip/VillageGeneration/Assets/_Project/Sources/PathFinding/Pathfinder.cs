﻿using System.Collections.Generic;
using Sources.VillageGeneration;
using UnityEngine;

namespace Sources.PathFinding
{
    public class Pathfinder
    {
        public List<Vector2Int> FindPath(Vector2Int start, Vector2Int target, CellType[,] grid, int width, int height)
        {
            List<Vector2Int> openSet = new() { start };
            Dictionary<Vector2Int, Vector2Int> cameFrom = new();
            Dictionary<Vector2Int, float> gScore = new() { { start, 0 } };

            while (openSet.Count > 0)
            {
                openSet.Sort((a, b) => 
                    (gScore[a] + GetHeuristic(a, target)).CompareTo(gScore[b] + GetHeuristic(b, target)));
            
                Vector2Int current = openSet[0];
                openSet.RemoveAt(0);

                if (current == target)
                    return ReconstructPath(cameFrom, current);

                foreach (Vector2Int neighbor in GetNeighbors(current, width, height))
                {
                    bool isWalkable = (grid[neighbor.x, neighbor.y] != CellType.Building) || (neighbor == target);
                
                    if (!isWalkable) 
                        continue;

                    float tentativeG = gScore[current] + 1;

                    if (!gScore.ContainsKey(neighbor) || tentativeG < gScore[neighbor])
                    {
                        cameFrom[neighbor] = current;
                        gScore[neighbor] = tentativeG;
                    
                        if (!openSet.Contains(neighbor)) 
                            openSet.Add(neighbor);
                    }
                }
            }

            return null;
        }

        private float GetHeuristic(Vector2Int a, Vector2Int b) => 
            Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);

        private List<Vector2Int> ReconstructPath(Dictionary<Vector2Int, Vector2Int> cameFrom, Vector2Int current)
        {
            List<Vector2Int> path = new() { current };
        
            while (cameFrom.ContainsKey(current))
            {
                current = cameFrom[current];
                path.Add(current);
            }
        
            path.Reverse();
            return path;
        }

        private List<Vector2Int> GetNeighbors(Vector2Int node, int width, int height)
        {
            List<Vector2Int> neighbors = new();
            Vector2Int[] dirs = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };

            foreach (Vector2Int dir in dirs)
            {
                Vector2Int next = node + dir;
            
                if (next.x >= 0 && next.x < width && next.y >= 0 && next.y < height) 
                    neighbors.Add(next);
            }
            return neighbors;
        }
    }
}