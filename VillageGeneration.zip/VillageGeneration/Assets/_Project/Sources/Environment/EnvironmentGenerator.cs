﻿using Sources.VillageGeneration;
using UnityEngine;
using UnityEngine.Tilemaps;

namespace Sources.Environment
{
    public class EnvironmentGenerator : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private Tilemap _groundTilemap;
        [SerializeField] private Tilemap _decorationTilemap;

        [Header("Assets")]
        [SerializeField] private RuleTile _baseGroundTile;
        [SerializeField] private TileBase _grassDetailTile;

        [Header("Settings")]
        [Range(0f, 1f)]
        [SerializeField] private float _grassDensity = 0.2f;

        public void GenerateEnvironment(VillageGenerationResult data)
        {
            Cleanup();

            for (int x = 0; x < data.Width; x++)
            {
                for (int y = 0; y < data.Height; y++)
                {
                    Vector3Int pos = new Vector3Int(x, y, 0);

                    // Земля
                    _groundTilemap.SetTile(pos, _baseGroundTile);
                    
                    // Трава
                    if (data.Grid[x, y] == CellType.Empty)
                    {
                        if (Random.value < _grassDensity && _grassDetailTile != null) 
                            _decorationTilemap.SetTile(pos, _grassDetailTile);
                    }
                }
            }
        }

        private void Cleanup()
        {
            if (_groundTilemap != null) 
                _groundTilemap.ClearAllTiles();
        
            if (_decorationTilemap != null) 
                _decorationTilemap.ClearAllTiles();
        }
    }
}